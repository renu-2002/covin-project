from django.conf import settings
from django.http import HttpResponseBadRequest, HttpResponseRedirect
from django.urls import reverse
from django.views.generic.base import View
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
import googleapiclient.discovery
import datetime

class GoogleCalendarInitView(View):
    def get(self, request):
        # Create the flow using the client ID and secret key
        flow = Flow.from_client_config(
            client_config={
                'client_id': settings.GOOGLE_CLIENT_ID,
                'client_secret': settings.GOOGLE_CLIENT_SECRET,
                'scope': settings.GOOGLE_CALENDAR_SCOPE,
            },
            redirect_uri=request.build_absolute_uri(reverse('google_calendar_redirect')),
        )

        # Generate the authorization URL and redirect the user to it
        authorization_url, _ = flow.authorization_url(prompt='consent')
        return HttpResponseRedirect(authorization_url)


class GoogleCalendarRedirectView(View):
    def get(self, request):
        # Get the code from the redirect URL
        code = request.GET.get('code')
        if not code:
            return HttpResponseBadRequest('No code provided')

        # Create the flow using the client ID and secret key
        flow = Flow.from_client_config(
            client_config={
                'client_id': settings.GOOGLE_CLIENT_ID,
                'client_secret': settings.GOOGLE_CLIENT_SECRET,
                'scope': settings.GOOGLE_CALENDAR_SCOPE,
            },
            redirect_uri=request.build_absolute_uri(reverse('google_calendar_redirect')),
        )

        # Exchange the code for access token and refresh token
        flow.fetch_token(code=code)

        # Use the credentials to access the Google Calendar API
        credentials = flow.credentials
        calendar_service = googleapiclient.discovery.build('calendar', 'v3', credentials=credentials)
        now = datetime.datetime.utcnow().isoformat() + 'Z'  # 'Z' indicates UTC time
        events_result = calendar_service.events().list(calendarId='primary', timeMin=now, maxResults=10, singleEvents=True, orderBy='startTime').execute()
        events = events_result.get('items', [])

        # Process the events and return the response
        response_data = []
        if not events:
            response_data.append('No events found')
        else:
            for event in events:
                start = event['start'].get('dateTime', event['start'].get('date'))
                response_data.append(f'{event["summary"]} ({start})')
        return JsonResponse(response_data, safe=False)

